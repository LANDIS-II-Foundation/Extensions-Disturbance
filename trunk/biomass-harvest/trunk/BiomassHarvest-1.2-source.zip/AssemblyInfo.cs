using System.Reflection;

[assembly: AssemblyDescription("Biomass Harvest Extension")]
[assembly: AssemblyProduct("LANDIS-II")]
[assembly: AssemblyCompany("Green Code LLC")]
[assembly: AssemblyCopyright("Copyright 2008 Green Code LLC")]
